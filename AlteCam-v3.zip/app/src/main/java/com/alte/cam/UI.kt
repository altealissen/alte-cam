package com.alte.cam

import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*

private val Y = Color(0xFFFFD60A)
private val Glass = Color(0xCC1C1C1E)
private val CTRL = 176.dp

@Composable
fun T(s: String, c: Color = Color.White, size: TextUnit = 12.sp, bold: Boolean = false, mod: Modifier = Modifier) =
    Text(s, color = c, fontSize = size, fontWeight = if (bold) FontWeight.SemiBold else FontWeight.Medium, modifier = mod)

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

fun fmt(v: Float): String =
    if (abs(v - v.roundToInt()) < 0.05f) v.roundToInt().toString() else String.format(java.util.Locale.US, "%.1f", v)

@Composable
fun AlteCamApp(cam: Cam, owner: LifecycleOwner) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var menu by remember { mutableStateOf(false) }
    var sub by remember { mutableStateOf("") }
    var count by remember { mutableIntStateOf(0) }
    var dial by remember { mutableStateOf(false) }
    var touching by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(true) }
    var focus by remember { mutableStateOf<Offset?>(null) }
    var hint by remember { mutableStateOf<String?>(null) }
    var white by remember { mutableStateOf(false) }
    var roll by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(cam.ready, cam.mode, cam.front, cam.night, cam.ratio, cam.vq, cam.fps, cam.uhdr) { if (cam.ready) cam.bind(owner) }
    LaunchedEffect(hint) { if (hint != null) { delay(1500); hint = null } }
    LaunchedEffect(focus) { if (focus != null) { delay(1200); focus = null } }
    LaunchedEffect(dial, touching, cam.zoom) { if (dial && !touching) { delay(1800); dial = false } }
    LaunchedEffect(white) { if (white) { delay(90); white = false } }

    DisposableEffect(cam.level) {
        val sm = ctx.getSystemService(SensorManager::class.java)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { roll = Math.toDegrees(atan2(e.values[0].toDouble(), e.values[1].toDouble())).toFloat() }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (cam.level) sm.registerListener(l, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }

    fun shutter() {
        if (count > 0) return
        if (cam.mode == Mode.VIDEO) { cam.toggleRecord(); return }
        scope.launch {
            if (cam.timer > 0) { for (i in cam.timer downTo 1) { count = i; delay(1000) }; count = 0 }
            white = true
            cam.shoot()
        }
    }

    val tall = cam.mode == Mode.VIDEO || cam.ratio == 1
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val d = LocalDensity.current
        val top = with(d) { WindowInsets.statusBars.getTop(d).toDp() } + 56.dp
        val bot = with(d) { WindowInsets.navigationBars.getBottom(d).toDp() }
        val ph = maxWidth * (if (tall) 16f / 9f else 4f / 3f)
        val overlap = (top + ph - (maxHeight - bot - CTRL)).coerceAtLeast(0.dp)

        // ---------- превью + жесты ----------
        Box(Modifier.align(Alignment.TopCenter).padding(top = top).fillMaxWidth().height(ph)) {
            AndroidView({ cam.view }, Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) { detectTapGestures(onTap = { o -> cam.focus(o.x, o.y); focus = o; menu = false; sub = "" }) }
                    .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> if (z != 1f) { cam.zoomTo(cam.zoom * z) } } }
            )
            if (cam.grid) Canvas(Modifier.fillMaxSize()) {
                val c = Color.White.copy(alpha = 0.35f)
                for (i in 1..2) {
                    drawLine(c, Offset(size.width * i / 3, 0f), Offset(size.width * i / 3, size.height), 2f)
                    drawLine(c, Offset(0f, size.height * i / 3), Offset(size.width, size.height * i / 3), 2f)
                }
            }
            if (cam.level) Canvas(Modifier.fillMaxSize()) {
                val ok = abs(roll) < 1.2f
                val half = if (ok) size.width * 0.32f else size.width * 0.18f
                rotate(-roll, Offset(size.width / 2, size.height / 2)) {
                    drawLine(if (ok) Y else Color.White, Offset(size.width / 2 - half, size.height / 2), Offset(size.width / 2 + half, size.height / 2), 4f)
                }
            }
            focus?.let { o ->
                val s = with(d) { 72.dp.toPx() }
                Canvas(Modifier.fillMaxSize()) { drawRect(Y, Offset(o.x - s / 2, o.y - s / 2), Size(s, s), style = androidx.compose.ui.graphics.drawscope.Stroke(4f)) }
            }
        }
        if (white) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.6f)))
        if (count > 0) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { T("$count", Color.White, 96.sp, true) }

        // ---------- макро / зум ----------
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = CTRL + bot + overlap).fillMaxWidth()) {
            if (cam.near && !cam.front) Box(
                Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 10.dp).size(40.dp)
                    .clip(CircleShape).background(Color(0x99000000))
                    .tap { cam.zoomTo(if (cam.zoom >= 1f) 0.5f else 1f) },
                contentAlignment = Alignment.Center
            ) { Tulip() }
            if (!cam.front) {
                if (dial) ZoomDial(cam.zoom, cam.minZ, cam.maxZ, { cam.zoomTo(it) }, { touching = it },
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 0.dp))
                else Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)) { Pills(cam) { dial = true } }
            }
        }

        // ---------- верхняя панель ----------
        Row(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().height(56.dp).fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.clip(CircleShape).background(Glass).then(if (cam.mode == Mode.VIDEO) Modifier.tap { panel = !panel } else Modifier)
                .padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (cam.mode == Mode.VIDEO) {
                    T(listOf("HD", "FHD", "4K")[cam.vq] + " · ${cam.fps}", Color.White, 13.sp, true)
                    T(if (panel) "  ⌃" else "  ⌄", Y, 13.sp, true)
                } else T(if (cam.uhdr) "UHDR" else "JPEG", Color.White, 13.sp, true)
            }
            if (cam.recording) Row(Modifier.clip(CircleShape).background(Color(0xFFFF3B30)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                T("%02d:%02d".format(cam.secs / 60, cam.secs % 60), Color.White, 13.sp, true)
            }
            Row(Modifier.clip(CircleShape).background(Glass).padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).tap { hint = cam.cycleFlash() }, contentAlignment = Alignment.Center) {
                    T("ϟ", if (cam.flash == 1) Y else Color.White, 20.sp, true)
                    if (cam.flash == 0) T("A", Color.White, 8.sp, true, Modifier.align(Alignment.BottomEnd).padding(6.dp))
                }
                if (cam.mode != Mode.VIDEO) Box(Modifier.size(40.dp).tap { cam.night = !cam.night; hint = if (cam.night) "НОЧНОЙ РЕЖИМ: ВКЛ." else "НОЧНОЙ РЕЖИМ: ВЫКЛ." },
                    contentAlignment = Alignment.Center) { T("☾", if (cam.night) Y else Color.White, 22.sp, true) }
            }
        }
        hint?.let {
            Box(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 64.dp).clip(CircleShape).background(Color.White).padding(horizontal = 12.dp, vertical = 5.dp)) {
                T(it, Color.Black, 12.sp, true)
            }
        }
        Box(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 62.dp, start = 14.dp, end = 14.dp)) {
            AnimatedVisibility(cam.mode == Mode.VIDEO && panel, enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Glass).padding(14.dp)
                        .pointerInput(Unit) { detectVerticalDragGestures { _, dy -> if (dy < -6) panel = false } },
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("РАЗРЕШЕНИЕ", Color.Gray, 11.sp, true, Modifier.width(96.dp))
                        listOf("HD", "FHD", "4K").forEachIndexed { i, s -> Chip(s, cam.vq == i) { cam.vq = i } }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        T("КАДР/С", Color.Gray, 11.sp, true, Modifier.width(96.dp))
                        listOf(24, 30, 60).forEach { f -> Chip("$f", cam.fps == f) { cam.fps = f } }
                    }
                    Box(Modifier.align(Alignment.CenterHorizontally).width(36.dp).height(4.dp).clip(CircleShape).background(Color.Gray))
                }
            }
        }

        // ---------- нижние элементы управления ----------
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().height(CTRL),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Glass).tap { menu = true; sub = "ev" }, contentAlignment = Alignment.Center) { T("ƒ", Color.White, 18.sp, true) }
                Box(Modifier.size(80.dp).tap { shutter() }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(78.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape))
                    if (cam.recording) Box(Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)).background(Color(0xFFFF3B30)))
                    else Box(Modifier.size(64.dp).clip(CircleShape).background(if (cam.mode == Mode.VIDEO) Color(0xFFFF3B30) else Color.White))
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(Glass).tap { menu = true; sub = "" }, contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(18.dp)) {
                        for (x in 0..2) for (y in 0..2) drawCircle(Color.White, size.width * 0.09f, Offset(size.width * (0.12f + x * 0.38f), size.height * (0.12f + y * 0.38f)))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Glass).tap {
                    cam.lastUri?.let { u -> runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, ctx.contentResolver.getType(u)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    } }
                }, contentAlignment = Alignment.Center) {
                    cam.thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
                var acc by remember { mutableFloatStateOf(0f) }
                Row(
                    Modifier.weight(1f).height(44.dp).clip(CircleShape).background(Glass).padding(3.dp)
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(onDragStart = { acc = 0f }) { _, dx ->
                                acc += dx
                                if (!cam.recording && abs(acc) > 70f) {
                                    val all = Mode.values(); val i = all.indexOf(cam.mode)
                                    val n = (if (acc < 0) i + 1 else i - 1).coerceIn(0, all.size - 1)
                                    cam.mode = all[n]; acc = 0f
                                }
                            }
                        }
                ) {
                    Mode.values().forEach { m ->
                        val sel = cam.mode == m
                        Box(Modifier.weight(1f).fillMaxHeight().clip(CircleShape).background(if (sel) Color(0x40FFFFFF) else Color.Transparent)
                            .tap { if (!cam.recording) cam.mode = m }, contentAlignment = Alignment.Center) {
                            T(m.title, if (sel) Y else Color.White, 13.sp, true)
                        }
                    }
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(Glass).tap { if (!cam.recording) { cam.front = !cam.front; cam.zoomTo(1f) } }, contentAlignment = Alignment.Center) {
                    T("⟳", Color.White, 22.sp, true)
                }
            }
        }

        // ---------- меню ----------
        AnimatedVisibility(menu, Modifier.align(Alignment.BottomCenter), enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            Column(
                Modifier.padding(horizontal = 12.dp, vertical = 12.dp).navigationBarsPadding().fillMaxWidth()
                    .clip(RoundedCornerShape(30.dp)).background(Color(0xF01C1C1E)).padding(18.dp)
                    .pointerInput(Unit) { detectVerticalDragGestures { _, dy -> if (dy > 8) { menu = false; sub = "" } } },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(Modifier.width(36.dp).height(4.dp).clip(CircleShape).background(Color.Gray))
                if (sub.isEmpty()) {
                    val tiles = listOf(
                        Tile("ВСПЫШКА", "ϟ", cam.flash == 1) { hint = cam.cycleFlash() },
                        Tile("СЕТКА", "#", cam.grid) { cam.grid = !cam.grid },
                        Tile("ФОРМАТ", if (cam.ratio == 0) "4:3" else "16:9", false) { sub = "ratio" },
                        Tile("ТАЙМЕР", if (cam.timer == 0) "⏱" else "${cam.timer}с", cam.timer > 0) { sub = "timer" },
                        Tile("ЭКСПОЗИЦИЯ", "±", cam.ev != 0) { sub = "ev" },
                        Tile("УРОВЕНЬ", "⊖", cam.level) { cam.level = !cam.level },
                        Tile("ГЛУБИНА", "◎", cam.mode == Mode.PORTRAIT) { if (!cam.recording) cam.mode = if (cam.mode == Mode.PORTRAIT) Mode.PHOTO else Mode.PORTRAIT },
                        Tile("НОЧНОЙ РЕЖИМ", "☾", cam.night) { cam.night = !cam.night },
                        Tile("ФАЙЛ", if (cam.uhdr) "UHDR" else "JPEG", cam.uhdr) { cam.uhdr = !cam.uhdr }
                    )
                    tiles.chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth()) { row.forEach { t -> Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { TileView(t) } } }
                    }
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        T("‹", Color.White, 28.sp, true, Modifier.tap { sub = "" }.padding(end = 16.dp))
                        T(when (sub) { "ratio" -> "ФОРМАТ"; "timer" -> "ТАЙМЕР"; else -> "ЭКСПОЗИЦИЯ" }, Color.White, 13.sp, true)
                    }
                    when (sub) {
                        "ratio" -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Chip("4:3", cam.ratio == 0) { cam.ratio = 0 }; Chip("16:9", cam.ratio == 1) { cam.ratio = 1 } }
                        "timer" -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { listOf(0, 3, 10).forEach { s -> Chip(if (s == 0) "Выкл" else "$s с", cam.timer == s) { cam.timer = s } } }
                        else -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                            Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x33FFFFFF)).tap { cam.evTo(cam.ev - 1) }, contentAlignment = Alignment.Center) { T("−", Color.White, 24.sp, true) }
                            T("%+.1f EV".format(cam.ev * cam.evStep), if (cam.ev != 0) Y else Color.White, 18.sp, true)
                            Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0x33FFFFFF)).tap { cam.evTo(cam.ev + 1) }, contentAlignment = Alignment.Center) { T("+", Color.White, 24.sp, true) }
                        }
                    }
                }
            }
        }
    }
}

class Tile(val label: String, val icon: String, val on: Boolean, val click: () -> Unit)

@Composable
fun TileView(t: Tile) {
    Column(Modifier.tap(t.click), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(if (t.on) Y.copy(alpha = 0.25f) else Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
            T(t.icon, if (t.on) Y else Color.White, 17.sp, true)
        }
        T(t.label, Color.White, 10.sp, true, Modifier.padding(top = 6.dp))
    }
}

@Composable
fun Chip(label: String, sel: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(end = 8.dp).clip(CircleShape).background(if (sel) Y.copy(alpha = 0.2f) else Color(0x22FFFFFF)).tap(onClick).padding(horizontal = 14.dp, vertical = 7.dp)) {
        T(label, if (sel) Y else Color.White, 13.sp, true)
    }
}

@Composable
fun Pills(cam: Cam, openDial: () -> Unit) {
    val presets = listOf(0.5f, 1f, 2f, 3f).filter { it >= cam.minZ - 0.01f && it <= cam.maxZ + 0.01f }
    val nearest = presets.minByOrNull { abs(it - cam.zoom) }
    Row(
        Modifier.clip(CircleShape).background(Color(0x59000000)).padding(4.dp)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { openDial() }) }
            .pointerInput(Unit) { detectHorizontalDragGestures(onDragStart = { openDial() }) { _, _ -> } },
        verticalAlignment = Alignment.CenterVertically
    ) {
        presets.forEach { p ->
            val sel = p == nearest
            val label = if (sel) fmt(cam.zoom) + "×" else fmt(p).removePrefix("0")
            Box(Modifier.size(if (sel) 42.dp else 34.dp).clip(CircleShape).background(if (sel) Color(0x99000000) else Color.Transparent).tap { cam.zoomTo(p) }, contentAlignment = Alignment.Center) {
                T(label, if (sel) Y else Color.White, 13.sp, true)
            }
        }
    }
}

@Composable
fun ZoomDial(zoom: Float, minZ: Float, maxZ: Float, onChange: (Float) -> Unit, onTouch: (Boolean) -> Unit, modifier: Modifier) {
    val z by rememberUpdatedState(zoom)
    val paint = remember { android.graphics.Paint().apply { isAntiAlias = true; textAlign = android.graphics.Paint.Align.CENTER; isFakeBoldText = true } }
    Canvas(
        modifier.fillMaxWidth().aspectRatio(1f / 0.3f)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(onDragStart = { onTouch(true) }, onDragEnd = { onTouch(false) }, onDragCancel = { onTouch(false) }) { _, dx ->
                    val perStop = size.width * 0.55f * 0.5236f
                    onChange(z * 2f.pow(-dx / perStop))
                }
            }
    ) {
        val w = size.width
        val r = w * 0.55f
        val cx = w / 2
        val cy = w * 0.02f + r
        val deg = 30f
        val z0 = log2(zoom)
        drawCircle(Color(0xB3000000), r, Offset(cx, cy))
        val lo = log2(minZ) - 0.001f
        val hi = log2(maxZ) + 0.001f
        for (i in -48..60) {
            val s = i / 12f
            if (s < lo || s > hi) continue
            val dg = (s - z0) * deg
            if (abs(dg) > 80f) continue
            val rad = Math.toRadians(90.0 - dg)
            val len = if (i % 12 == 0) 30f else 16f
            val a = Offset(cx + r * cos(rad).toFloat(), cy - r * sin(rad).toFloat())
            val b = Offset(cx + (r - len) * cos(rad).toFloat(), cy - (r - len) * sin(rad).toFloat())
            drawLine(Color.White.copy(alpha = 1f - abs(dg) / 100f), a, b, if (i % 12 == 0) 4f else 2.5f)
        }
        val nc = drawContext.canvas.nativeCanvas
        paint.textSize = 40f
        paint.color = android.graphics.Color.WHITE
        for (v in listOf(0.5f, 1f, 2f, 3f, 5f, 8f, 10f, 15f)) {
            if (v < minZ - 0.01f || v > maxZ + 0.01f) continue
            val dg = (log2(v) - z0) * deg
            if (abs(dg) > 70f || abs(dg) < 6f) continue
            val rad = Math.toRadians(90.0 - dg)
            val px = cx + (r - 70f) * cos(rad).toFloat()
            val py = cy - (r - 70f) * sin(rad).toFloat()
            nc.save(); nc.rotate(dg, px, py); nc.drawText(fmt(v), px, py, paint); nc.restore()
        }
        paint.color = android.graphics.Color.rgb(255, 214, 10)
        paint.textSize = 54f
        nc.drawText(fmt(zoom).let { if (zoom % 1f != 0f) String.format(java.util.Locale.US, "%.1f", zoom) else it } + "×", cx, cy - r + 120f, paint)
        val tri = Path().apply { moveTo(cx - 12f, cy - r + 4f); lineTo(cx + 12f, cy - r + 4f); lineTo(cx, cy - r + 28f); close() }
        drawPath(tri, Y)
    }
}

@Composable
fun Tulip() {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * .2f, w * .18f); lineTo(w * .38f, w * .34f); lineTo(w * .5f, w * .14f); lineTo(w * .62f, w * .34f); lineTo(w * .8f, w * .18f)
            cubicTo(w * .88f, w * .5f, w * .72f, w * .72f, w * .5f, w * .72f)
            cubicTo(w * .28f, w * .72f, w * .12f, w * .5f, w * .2f, w * .18f); close()
        }
        drawPath(p, Y)
        drawLine(Y, Offset(w * .5f, w * .7f), Offset(w * .5f, w * .95f), w * .08f)
        drawLine(Y, Offset(w * .5f, w * .88f), Offset(w * .26f, w * .74f), w * .07f)
        drawLine(Y, Offset(w * .5f, w * .88f), Offset(w * .74f, w * .74f), w * .07f)
    }
}
