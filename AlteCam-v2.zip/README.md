# Alte Cam
Камера в стиле iOS 27 для Pixel 8 (CameraX: 0.5× ультраширик + 1× основная, Night/HDR/Bokeh-расширения).
Сборка: залей содержимое в GitHub → Actions → Build APK → Artifacts → AlteCam-apk (app-debug.apk).
