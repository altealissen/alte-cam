package com.alte.cam

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.core.util.Consumer
import androidx.lifecycle.LifecycleOwner
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Mode(val title: String) { VIDEO("ВИДЕО"), PHOTO("ФОТО"), PORTRAIT("ПОРТРЕТ") }

@OptIn(ExperimentalCamera2Interop::class)
class Cam(private val ctx: Context) {
    private val exec = ContextCompat.getMainExecutor(ctx)
    val view = PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }

    var ready by mutableStateOf(false)
    var mode by mutableStateOf(Mode.PHOTO)
    var front by mutableStateOf(false)
    var zoom by mutableFloatStateOf(1f)
    var minZ by mutableFloatStateOf(0.5f)
    var maxZ by mutableFloatStateOf(8f)
    var flash by mutableIntStateOf(0)          // 0 авто, 1 вкл, 2 выкл
    var night by mutableStateOf(false)
    var grid by mutableStateOf(false)
    var level by mutableStateOf(false)
    var timer by mutableIntStateOf(0)
    var ev by mutableIntStateOf(0)
    var evMin by mutableIntStateOf(0)
    var evMax by mutableIntStateOf(0)
    var evStep by mutableFloatStateOf(1f)
    var ratio by mutableIntStateOf(0)          // 0 = 4:3, 1 = 16:9
    var uhdr by mutableStateOf(false)
    var vq by mutableIntStateOf(2)             // 0 HD, 1 FHD, 2 4K
    var fps by mutableIntStateOf(30)
    var recording by mutableStateOf(false)
    var secs by mutableIntStateOf(0)
    var near by mutableStateOf(false)          // близкий фокус -> значок макро
    var thumb by mutableStateOf<Bitmap?>(null)
    var lastUri: Uri? = null

    private var provider: ProcessCameraProvider? = null
    private var ext: ExtensionsManager? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var rec: Recording? = null
    private var started = false
    private var safe = false

    fun start() {
        if (started) return
        started = true
        initThumb()
        val f = ProcessCameraProvider.getInstance(ctx)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(ctx, provider!!)
            ef.addListener({ ext = runCatching { ef.get() }.getOrNull(); ready = true }, exec)
        }, exec)
    }

    fun bind(owner: LifecycleOwner) {
        val p = provider ?: return
        if (recording) return
        p.unbindAll()
        val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val tall = mode == Mode.VIDEO || ratio == 1
        val rs = ResolutionSelector.Builder().setAspectRatioStrategy(
            if (tall) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        ).build()

        val pb = Preview.Builder().setResolutionSelector(rs)
        Camera2Interop.Extender(pb).setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                val d = res.get(CaptureResult.LENS_FOCUS_DISTANCE) ?: return
                val n = d >= 7f   // ближе ~14 см
                if (n != near) near = n
            }
        })
        val preview = pb.build()
        preview.setSurfaceProvider(view.surfaceProvider)

        try {
            if (mode == Mode.VIDEO) {
                val q = when (vq) { 0 -> Quality.HD; 1 -> Quality.FHD; else -> Quality.UHD }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(q, FallbackStrategy.lowerQualityOrHigherThan(q))).build()
                val vb = VideoCapture.Builder(recorder)
                if (!safe) vb.setTargetFrameRate(Range(fps, fps))
                videoCapture = vb.build()
                imageCapture = null
                camera = p.bindToLifecycle(owner, base, preview, videoCapture!!)
            } else {
                val em: Int? = when {
                    safe || front -> null
                    mode == Mode.PORTRAIT -> ExtensionMode.BOKEH
                    night -> ExtensionMode.NIGHT
                    !uhdr -> ExtensionMode.HDR
                    else -> null
                }
                val useUhdr = uhdr && em == null && !safe && Build.VERSION.SDK_INT >= 34
                val icb = ImageCapture.Builder().setResolutionSelector(rs)
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(flashMode())
                if (useUhdr) icb.setOutputFormat(ImageCapture.OUTPUT_FORMAT_JPEG_ULTRA_HDR)
                imageCapture = icb.build()
                videoCapture = null
                var sel = base
                val x = ext
                if (em != null && x != null && x.isExtensionAvailable(base, em)) sel = x.getExtensionEnabledCameraSelector(base, em)
                camera = p.bindToLifecycle(owner, sel, preview, imageCapture!!)
            }
        } catch (e: Exception) {
            p.unbindAll()
            if (!safe) { safe = true; bind(owner); safe = false }
            return
        }
        camera?.let { c ->
            val zs = c.cameraInfo.zoomState.value
            minZ = zs?.minZoomRatio ?: 1f
            maxZ = minOf(zs?.maxZoomRatio ?: 8f, 15f)
            val r = c.cameraInfo.exposureState.exposureCompensationRange
            evMin = r.lower; evMax = r.upper
            evStep = c.cameraInfo.exposureState.exposureCompensationStep.toFloat()
            ev = ev.coerceIn(evMin, evMax)
            c.cameraControl.setExposureCompensationIndex(ev)
            setZoom(if (front) 1f else zoom)
            applyTorch()
        }
    }

    private fun flashMode() = when (flash) { 1 -> ImageCapture.FLASH_MODE_ON; 2 -> ImageCapture.FLASH_MODE_OFF; else -> ImageCapture.FLASH_MODE_AUTO }

    private fun applyTorch() { camera?.cameraControl?.enableTorch(mode == Mode.VIDEO && flash == 1) }

    fun cycleFlash(): String {
        flash = (flash + 1) % 3
        if (mode == Mode.VIDEO && flash == 0) flash = 1
        imageCapture?.flashMode = flashMode()
        applyTorch()
        return when (flash) { 0 -> "ВСПЫШКА: АВТО"; 1 -> "ВСПЫШКА: ВКЛ."; else -> "ВСПЫШКА: ВЫКЛ." }
    }

    fun setEv(i: Int) { ev = i.coerceIn(evMin, evMax); camera?.cameraControl?.setExposureCompensationIndex(ev) }

    fun setZoom(z: Float) {
        val c = z.coerceIn(minZ, maxZ)
        zoom = c
        camera?.cameraControl?.setZoomRatio(c)
    }

    fun focus(x: Float, y: Float) {
        val pt = view.meteringPointFactory.createPoint(x, y)
        camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun shoot() {
        val ic = imageCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ALTE_${stamp()}")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AlteCam")
        }
        val out = ImageCapture.OutputFileOptions.Builder(ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            .setMetadata(ImageCapture.Metadata().apply { isReversedHorizontal = front }).build()
        ic.takePicture(out, exec, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) { lastUri = r.savedUri; loadThumb() }
            override fun onError(e: ImageCaptureException) {}
        })
    }

    @SuppressLint("MissingPermission")
    fun toggleRecord() {
        if (rec != null) { rec?.stop(); return }
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ALTE_${stamp()}")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AlteCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pending = vc.output.prepareRecording(ctx, opts)
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            pending = pending.withAudioEnabled()
        rec = pending.start(exec, Consumer<VideoRecordEvent> { e ->
            when (e) {
                is VideoRecordEvent.Status -> secs = (e.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                is VideoRecordEvent.Finalize -> {
                    recording = false; rec = null; secs = 0
                    if (!e.hasError()) { lastUri = e.outputResults.outputUri; loadThumb() }
                }
                else -> {}
            }
        })
        recording = true
    }

    fun loadThumb() {
        val u = lastUri ?: return
        Thread { try { thumb = ctx.contentResolver.loadThumbnail(u, Size(160, 160), null) } catch (_: Exception) {} }.start()
    }

    private fun initThumb() {
        Thread {
            try {
                val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                ctx.contentResolver.query(uri, arrayOf(MediaStore.Images.Media._ID), null, null, "date_added DESC")?.use { c ->
                    if (c.moveToFirst()) { lastUri = ContentUris.withAppendedId(uri, c.getLong(0)); loadThumb() }
                }
            } catch (_: Exception) {}
        }.start()
    }
}
